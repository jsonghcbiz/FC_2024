import streamlit as st
from library.wicked_recommender import main as wicked_main

def main():
    wicked_main()

if __name__ == "__main__":
    main()

